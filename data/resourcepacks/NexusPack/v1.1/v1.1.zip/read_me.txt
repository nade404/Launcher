Textures based on Conquest (http://conquest.ravand.org/)
Credits to:
Monsterfish - Dc: Monsterfish_#7254
Finn - Dc: doofefrage#6264